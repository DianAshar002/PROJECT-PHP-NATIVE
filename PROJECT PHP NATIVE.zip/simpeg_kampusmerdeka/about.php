<section class="news section">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section-title">
                    <h3>About <span class="alternate">Us</span></h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit sed do eiusm tempor incididunt ut labore
                        dolore</p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-4 col-md-6 col-sm-8 col-10 m-auto">
                <div class="blog-post">
                    <div class="post-thumb">
                        <a href="news-single.html">
                            <img src="images/news/post-thumb-one.jpg" alt="post-image" class="img-fluid">
                        </a>
                    </div>
                    <div class="post-content">
                        <div class="date">
                            <h4>20<span>May</span></h4>
                        </div>
                        <div class="post-title">
                            <h2><a href="news-single.html">Elementum purus id ultrices.</a></h2>
                        </div>
                        <div class="post-meta">
                            <ul class="list-inline">
                                <li class="list-inline-item">
                                    <i class="fa fa-user-o"></i>
                                    <a href="#">Admin</a>
                                </li>
                                <li class="list-inline-item">
                                    <i class="fa fa-heart-o"></i>
                                    <a href="#">350</a>
                                </li>
                                <li class="list-inline-item">
                                    <i class="fa fa-comments-o"></i>
                                    <a href="#">30</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-8 col-10 m-auto">
                <div class="blog-post">
                    <div class="post-thumb">
                        <a href="news-single.html">
                            <img src="images/news/post-thumb-two.jpg" alt="post-image" class="img-fluid">
                        </a>
                    </div>
                    <div class="post-content">
                        <div class="date">
                            <h4>20<span>May</span></h4>
                        </div>
                        <div class="post-title">
                            <h2><a href="news-single.html">Elementum purus id ultrices.</a></h2>
                        </div>
                        <div class="post-meta">
                            <ul class="list-inline">
                                <li class="list-inline-item">
                                    <i class="fa fa-user-o"></i>
                                    <a href="#">Admin</a>
                                </li>
                                <li class="list-inline-item">
                                    <i class="fa fa-heart-o"></i>
                                    <a href="#">350</a>
                                </li>
                                <li class="list-inline-item">
                                    <i class="fa fa-comments-o"></i>
                                    <a href="#">30</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 m-md-auto col-sm-8 col-10 m-auto">
                <div class="blog-post">
                    <div class="post-thumb">
                        <a href="news-single.html">
                            <img src="images/news/post-thumb-three.jpg" alt="post-image" class="img-fluid">
                        </a>
                    </div>
                    <div class="post-content">
                        <div class="date">
                            <h4>20<span>May</span></h4>
                        </div>
                        <div class="post-title">
                            <h2><a href="news-single.html">Elementum purus id ultrices.</a></h2>
                        </div>
                        <div class="post-meta">
                            <ul class="list-inline">
                                <li class="list-inline-item">
                                    <i class="fa fa-user-o"></i>
                                    <a href="#">Admin</a>
                                </li>
                                <li class="list-inline-item">
                                    <i class="fa fa-heart-o"></i>
                                    <a href="#">350</a>
                                </li>
                                <li class="list-inline-item">
                                    <i class="fa fa-comments-o"></i>
                                    <a href="#">30</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>